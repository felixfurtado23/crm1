import React from 'react';
import InvoicesTable from '../components/InvoicesTable';

const Invoicing = () => {
  return (
    <>
      <InvoicesTable />
    </>
  );
};

export default Invoicing;