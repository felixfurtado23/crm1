import React from 'react';
import LeadsTable from '../components/LeadsTable';
import SimpleLeads from '../components/SimpleLeads';

const Leads = () => {
  return (
    <>
     
      <LeadsTable />
   
    </>
  );
};

export default Leads;