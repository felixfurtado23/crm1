import React from 'react';
import CustomersTable from '../components/CustomersTable';

const Customers = () => {
  return (
    <>
      <CustomersTable />
    </>
  );
};

export default Customers;